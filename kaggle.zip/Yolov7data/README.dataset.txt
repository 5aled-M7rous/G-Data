# Data > 2024-02-17 2:28am
https://universe.roboflow.com/helwan-xssjn/data-h6qx3

Provided by a Roboflow user
License: CC BY 4.0

